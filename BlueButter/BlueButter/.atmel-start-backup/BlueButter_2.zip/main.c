#include <atmel_start.h>
#include <util/delay.h>
#include <usart_basic.h>

static uint8_t rx[16];

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	USART_0_init();
	USART_0_enable();
	USART_0_enable_rx();
	USART_0_enable_tx();
	while (1) {
/*		LED_set_level(true);
		_delay_ms(100);
		LED_set_level(false);
		_delay_ms(100);
*/		LED_set_level(true);
		_delay_ms(100);
		LED_set_level(false);
		_delay_ms(2000);
		while(!USART_0_is_tx_ready()){}; /* wait for Tx to be ready */
		USART_0_write("H");
		USART_0_write("i");
}
